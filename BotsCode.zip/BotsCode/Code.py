from PIL import ImageGrab
import os
import time
import win32api
import win32con

#Globals
x_pad = 435
y_pad = 347

"""
    Plate Cords
    1. (90,205)
    2. (198,212)
    3. (297,211)
    4. (390,209)
    5.(493,209)
    6. (591,211)
"""


class cord:
    f_shrimp = (38,322)
    f_rice = (97,321)
    f_nori = (39,376)
    f_roe = (101,384)
    f_salmon = (32,437)
    f_unagi = (99,436)

def screenGrab():
    box = (x_pad+1,y_pad+1,x_pad+639,y_pad+480)
    im = ImageGrab.grab(box)
    im.save(os.getcwd() + '\\full_snap__' + str(int(time.time())) +
            '.png', 'PNG')

def main():
    pass

def LeftClick():
    win32api.mouse_event(win32con.MOUSEEVENTF_LEFTDOWN,0,0)
    time.sleep(.1)
    win32api.mouse_event(win32con.MOUSEEVENTF_LEFTUP,0,0)
    print("click") #debugging

def LeftDown():
    win32api.mouse_event(win32con.MOUSEEVENTF_LEFTDOWN,0,0)
    time.sleep(.1)
    print('leftdown')

def LeftUp():
    win32api.mouse_event(win32con.MOUSEEVENTF_LEFTUP, 0, 0)
    time.sleep(.1)
    print('left release')

def mousePos(cord):
    win32api.SetCursorPos((x_pad+cord[0],y_pad+cord[1]))

def getcords():
    x,y = win32api.GetCursorPos()
    x = x - x_pad
    y = y - y_pad
    print (x,y)

def startGame():
        # Location of first menu
        mousePos((300,197))
        LeftClick()
        time.sleep(.1)

        # Location of second menu
        mousePos((322,383))
        LeftClick()
        time.sleep(.1)

        # Location of third menu
        mousePos((589,448))
        LeftClick()
        time.sleep(.1)

        # Location of fourth menu
        mousePos((322,377))
        LeftClick()
        time.sleep(.1)

   

if __name__ == '__main__':
    main()
